"""
================================================================================
PocketSmart AI — Single-File Fullstack Application (Naan Mudhalvan Project)
Frontend (HTML/CSS/JS) + Backend (FastAPI API) + Database (SQLite) in ONE File!
================================================================================
Run Command:
    python pocketsmart_app.py
================================================================================
"""

import os
import sqlite3
import datetime
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel

# ------------------------------------------------------------------------------
# 1. DATABASE ENGINE (SQLite)
# ------------------------------------------------------------------------------
DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pocketsmart.db")

def get_db():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            amount REAL NOT NULL,
            type TEXT NOT NULL,
            category TEXT NOT NULL,
            date TEXT NOT NULL
        )
    ''')
    cursor.execute('SELECT COUNT(*) FROM transactions')
    if cursor.fetchone()[0] == 0:
        sample_data = [
            ('Monthly Salary', 50000.0, 'income', 'Income / Salary', '2026-10-01'),
            ('House Rent', 15000.0, 'expense', 'Rent & Housing', '2026-10-01'),
            ('Swiggy Food Order', 3200.0, 'expense', 'Food & Dining', '2026-09-28'),
            ('Grocery Supermarket', 4500.0, 'expense', 'Food & Dining', '2026-09-26'),
            ('Electricity & Wi-Fi', 2100.0, 'expense', 'Rent & Housing', '2026-09-25'),
            ('Headphones Purchase', 3900.0, 'expense', 'Shopping & Tech', '2026-09-20')
        ]
        cursor.executemany('''
            INSERT INTO transactions (title, amount, type, category, date)
            VALUES (?, ?, ?, ?, ?)
        ''', sample_data)
    conn.commit()
    conn.close()

# ------------------------------------------------------------------------------
# 2. BACKEND API (FastAPI)
# ------------------------------------------------------------------------------
app = FastAPI(title="PocketSmart AI Fullstack Single File App")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class TransactionModel(BaseModel):
    title: str
    amount: float
    type: str
    category: str
    date: str = None

@app.on_event("startup")
def startup_event():
    init_db()

@app.get("/api/transactions")
def read_transactions():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM transactions ORDER BY id DESC')
    rows = cursor.fetchall()
    conn.close()
    return {"transactions": [dict(r) for r in rows]}

@app.post("/api/transactions")
def add_transaction(tx: TransactionModel):
    date_str = tx.date or datetime.date.today().isoformat()
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO transactions (title, amount, type, category, date)
        VALUES (?, ?, ?, ?, ?)
    ''', (tx.title, tx.amount, tx.type, tx.category, date_str))
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return {"status": "success", "id": new_id}

@app.delete("/api/transactions/{tx_id}")
def delete_transaction(tx_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM transactions WHERE id = ?', (tx_id,))
    conn.commit()
    conn.close()
    return {"status": "success", "deleted_id": tx_id}

# ------------------------------------------------------------------------------
# 3. FRONTEND UI (Embedded HTML / CSS / JS)
# ------------------------------------------------------------------------------
HTML_CONTENT = r'''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>PocketSmart AI | Smart Budget & AI Assistant</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <style>
    :root {
      --bg-dark: #090d16;
      --card-bg: rgba(23, 32, 54, 0.75);
      --card-border: rgba(255, 255, 255, 0.08);
      --accent: linear-gradient(135deg, #06b6d4 0%, #3b82f6 50%, #8b5cf6 100%);
      --btn-grad: linear-gradient(135deg, #0284c7 0%, #2563eb 100%);
      --text: #f8fafc;
      --muted: #94a3b8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Inter', sans-serif; }
    body { background-color: var(--bg-dark); color: var(--text); min-height: 100vh; display: flex; flex-direction: column; }
    header { background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(16px); border-bottom: 1px solid var(--card-border); padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; sticky; top: 0; position: }
    .brand { display: flex; align-items: center; gap: 12px; }
    .brand-icon { width: 40px; height: 40px; background: var(--accent); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; color: white; }
    .brand-title { font-size: 1.4rem; font-weight: 800; background: var(--accent); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
    .container { max-width: 1400px; margin: 0 auto; padding: 2rem; width: 100%; flex: 1; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.25rem; margin-bottom: 2rem; }
    .stat-card { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 16px; padding: 1.25rem; }
    .stat-value { font-size: 1.8rem; font-weight: 800; color: white; margin-top: 6px; }
    .dashboard-grid { display: grid; grid-template-columns: 1fr 1fr 1.1fr; gap: 1.5rem; }
    @media(max-width: 1000px){ .dashboard-grid { grid-template-columns: 1fr; } }
    .panel { background: var(--card-bg); border: 1px solid var(--card-border); border-radius: 18px; padding: 1.5rem; }
    .panel-title { font-size: 1.1rem; font-weight: 700; color: #38bdf8; margin-bottom: 1rem; }
    .form-control { width: 100%; background: rgba(15, 23, 42, 0.8); border: 1px solid var(--card-border); border-radius: 10px; padding: 10px 14px; color: white; margin-bottom: 12px; outline: none; }
    .btn-action { width: 100%; background: var(--btn-grad); color: white; border: none; padding: 12px; border-radius: 10px; font-weight: 700; cursor: pointer; }
    .tx-item { background: rgba(15, 23, 42, 0.6); border: 1px solid var(--card-border); border-radius: 12px; padding: 12px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .ai-box { background: rgba(15, 23, 42, 0.7); border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 14px; padding: 1.25rem; margin-bottom: 1.25rem; }
    .btn-del { color: #ef4444; background: none; border: none; cursor: pointer; font-size: 0.9rem; }
    footer { text-align: center; padding: 1.5rem; color: var(--muted); border-top: 1px solid var(--card-border); margin-top: 2rem; font-size: 0.85rem; }
  </style>
</head>
<body>
  <header>
    <div class="brand">
      <div class="brand-icon"><i class="fa-solid fa-wallet"></i></div>
      <div>
        <div class="brand-title">PocketSmart AI</div>
        <small style="color: var(--muted);">Fullstack Single File App • SQLite DB Active</small>
      </div>
    </div>
  </header>

  <div class="container">
    <div class="stats-grid">
      <div class="stat-card">
        <small style="color: var(--muted);">MONTHLY INCOME</small>
        <div class="stat-value" id="valIncome">₹0</div>
      </div>
      <div class="stat-card">
        <small style="color: var(--muted);">TOTAL EXPENSES</small>
        <div class="stat-value" id="valExpense">₹0</div>
      </div>
      <div class="stat-card">
        <small style="color: var(--muted);">NET SAVINGS</small>
        <div class="stat-value" id="valSavings">₹0</div>
      </div>
      <div class="stat-card">
        <small style="color: var(--muted);">AI HEALTH SCORE</small>
        <div class="stat-value" id="valScore">85 / 100</div>
      </div>
    </div>

    <div class="dashboard-grid">
      <div class="panel">
        <div class="panel-title"><i class="fa-solid fa-plus"></i> Add Transaction</div>
        <form id="txForm" onsubmit="addTx(event)">
          <input type="text" id="txTitle" class="form-control" placeholder="Description (e.g. Rent, Salary)" required />
          <input type="number" id="txAmount" class="form-control" placeholder="Amount (₹)" required />
          <select id="txType" class="form-control">
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>
          <select id="txCategory" class="form-control">
            <option value="Food & Dining">Food & Dining</option>
            <option value="Rent & Housing">Rent & Housing</option>
            <option value="Shopping & Tech">Shopping & Tech</option>
            <option value="Transport & Fuel">Transport & Fuel</option>
            <option value="Income / Salary">Income / Salary</option>
          </select>
          <button type="submit" class="btn-action">Add Record</button>
        </form>
      </div>

      <div class="panel">
        <div class="panel-title"><i class="fa-solid fa-receipt"></i> Recent Activity</div>
        <div id="txList"></div>
      </div>

      <div class="panel">
        <div class="panel-title" style="color: #c084fc;"><i class="fa-solid fa-brain"></i> AI Recommendation Engine</div>
        <div class="ai-box" id="aiInsight">Analyzing spending habits...</div>
      </div>
    </div>
  </div>

  <footer>
    PocketSmart AI Fullstack Application • Single File Integration (HTML + FastAPI + SQLite)
  </footer>

  <script>
    const API = '/api/transactions';
    let txs = [];

    document.addEventListener('DOMContentLoaded', fetchTx);

    async function fetchTx() {
      try {
        const res = await fetch(API);
        const data = await res.json();
        txs = data.transactions;
        render();
      } catch(e) {}
    }

    async function addTx(e) {
      e.preventDefault();
      const payload = {
        title: document.getElementById('txTitle').value,
        amount: parseFloat(document.getElementById('txAmount').value),
        type: document.getElementById('txType').value,
        category: document.getElementById('txCategory').value
      };
      await fetch(API, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
      });
      document.getElementById('txForm').reset();
      fetchTx();
    }

    async function delTx(id) {
      await fetch(`${API}/${id}`, { method: 'DELETE' });
      fetchTx();
    }

    function render() {
      const inc = txs.filter(t => t.type === 'income').reduce((a,b) => a + b.amount, 0);
      const exp = txs.filter(t => t.type === 'expense').reduce((a,b) => a + b.amount, 0);
      const net = inc - exp;

      document.getElementById('valIncome').innerText = `₹${inc.toLocaleString('en-IN')}`;
      document.getElementById('valExpense').innerText = `₹${exp.toLocaleString('en-IN')}`;
      document.getElementById('valSavings').innerText = `₹${net.toLocaleString('en-IN')}`;

      document.getElementById('txList').innerHTML = txs.map(t => `
        <div class="tx-item">
          <div>
            <strong>${t.title}</strong><br>
            <small style="color:var(--muted);">${t.category} • ${t.date}</small>
          </div>
          <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-weight:700; color:${t.type==='expense'?'#f43f5e':'#10b981'};">
              ${t.type==='expense'?'-':'+'} ₹${t.amount.toLocaleString('en-IN')}
            </span>
            <button class="btn-del" onclick="delTx(${t.id})"><i class="fa-solid fa-trash"></i></button>
          </div>
        </div>
      `).join('');

      const insight = document.getElementById('aiInsight');
      if (inc === 0) {
        insight.innerHTML = "💡 Add your monthly salary to activate AI Recommendation analytics.";
      } else if (exp > inc * 0.7) {
        insight.innerHTML = `⚠️ <strong>High Expenditure Alert:</strong> You spent <strong>${Math.round((exp/inc)*100)}%</strong> of your income. Consider reducing dining out.`;
      } else {
        insight.innerHTML = `✨ <strong>Optimal Savings Rate:</strong> You are saving <strong>₹${net.toLocaleString('en-IN')}</strong> (${Math.round((net/inc)*100)}% of income). On track!`;
      }
    }
  </script>
</body>
</html>

'''

@app.get("/", response_class=HTMLResponse)
def serve_home():
    return HTML_CONTENT

if __name__ == "__main__":
    print("=" * 65)
    print("Starting PocketSmart AI Single-File Fullstack App...")
    print("Main App URL: http://127.0.0.1:8090")
    print("=" * 65)
    uvicorn.run(app, host="127.0.0.1", port=8090)
