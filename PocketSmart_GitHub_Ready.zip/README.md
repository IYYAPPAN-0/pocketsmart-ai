# PocketSmart AI

A single-file FastAPI + SQLite + HTML/CSS/JavaScript personal finance dashboard.

## Run locally

### Windows
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python pocketsmart_app.py
```

Open: http://127.0.0.1:8090

The SQLite database (`pocketsmart.db`) is created automatically and is intentionally ignored by Git.

## GitHub

```powershell
git init
git add .
git commit -m "Initial PocketSmart AI app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/PocketSmart.git
git push -u origin main
```
